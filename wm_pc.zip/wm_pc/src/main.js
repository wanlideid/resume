import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
/*引入模块*/
import axios from 'axios'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min'

Vue.config.productionTip = false
axios.default.withCredentials=true
Vue.prototype.axios = axios;

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
