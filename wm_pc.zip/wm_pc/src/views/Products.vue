<template>
    <div id="main">
        <div class="my_row d-flex" id="plist" style="flex-wrap:wrap">
            <div class="my_product mr-3 mb-3" v-for="item in res.products" :key="item.lid">
                    <div class="myImag">
                       <router-link :to="`/details/${item.lid}`">
                           <img :src='`http://localhost:3000/${item.md}`' alt="">
                       </router-link> 
                    </div>
                    <div class="pl-1 mr-1 my_size mt-3" >
                        {{item.title}}
                    </div>
                    <div class="mt-4 my_fl ml-5 myPrice" >
                        <span  style="font-size:13px;margin-right:200px">RMB:
                            <i class="my_price ml-2">{{item.price.toFixed(2)}}</i>
                        </span>
                        <div class="pr-0 mt-1">
                            <router-link :to="'/cart/?lid='+item.lid" >
                                <img src="http://localhost:3000/img/products/cart.jpg" alt="" class="Image">
                            </router-link>
                        </div>
                    </div>
                    <div class="my_fl mt-1 ml-5">
                        <img src='http://localhost:3000/img/products/zan.jpg' alt="">
                        "("<span>0</span>")"
                    </div>
            </div>
        </div>
        <div class="mb-3 mt-1">
            <nav aria-label="Page navigation example" >
                <ul class="pagination mb-0 justify-content-center" v-for="pno in res.pno" :key="pno.id">
                    <li class="page-item " :class="pno==0?'disabled':''" ><a class="page-link bg-transparent" href="#" @click.prevent="prev()">上一页</a></li>
                    <li class="page-item" v-for="p in res.pageCount" :class="{'active':pno == p-1}" :key="p.id" @click="now(p)">
                        <router-link class="page-link " to="" >{{p}}</router-link>
                    </li>
                    <li class="page-item" 
                    :class="{disabled:hasMore}">
                        <a class="page-link bg-transparent" href="#" @click.prevent="next()">下一页</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</template>

<script>
    import '../../public/css/base.css'
    export default {
        data:function(){
            return {
                res:{},
                pno:0,
                pageCount:"",
                hasMore:false
            }
        },
        props:["kwords"],
        mounted(){
            this.loadmore()
        },
        methods:{
            loadmore(){
                this.axios.get("http://localhost:3000/products/getProducts",{params:{kwords:this.kwords,pno:this.pno}}).then(res=>{
                    this.res = res.data
                    this.pno = res.data.pno
                    this.pageCount = res.data.pageCount
                })
                if(this.pno==this.res.pageCount-1){
                   this.hasMore=true
                   console.log(this.hasMore)
                }else{
                   this.hasMore=false 
                }
            },
            prev(){
               this.pno=this.pno-1;
               this.loadmore()
            },
            next(){
                if(this.pno<this.res.pageCount-1){
                   this.pno++;
                   this.loadmore()
                }
            },
            now(p){
                this.pno = p-1;
                
                this.loadmore()
                
            }
        }
    }
</script>

<style scoped>
    *{
        margin: 0;
        padding: 0;
        list-style: none;
    }
    #main .mt-1 ul>:nth-child(2){
        display: flex;
        justify-content: center;
    }
    #main .Image{
        width: 23px;
        height: 23px;
    }
    #main div.myPrice{
        display: flex;
        justify-content: center;
    } 
    #main .my_product{
        width: 403px;
        height: 554px;
        border: 1px solid #DBDBDB;
    }
    #main .my_size{
        font-size: 18px;
    }
    #main .my_price{
        color: #F04D37;
        font-size: 20px;
    }
    #main .my_fr{
        float: right ;
        clear: both;
    }
    #main .my_fl{
        float: left !important;
        clear: both;
    }
    #main .my_row{
        margin-left: 100px !important;
        margin-top: 30px;
    }
</style>
