<template>
    <div id="my_lv">
        <form action="">
            <div class="mb-5 ">
                <input type="text" placeholder="用户名/手机号" class="my_control uname" v-model="uname">
            </div>
            <div class="">
                <input type="password" placeholder="密码" class="my_control upwd" v-model="upwd">
            </div>
            <div class="mt-4 mb-3 my_right">
                <a href="" class="m_small m_hover">忘记密码?</a>
            </div>
            <div>
                <button class="my_button" id="btn_login" @click="login()">登&nbsp;录</button>
            </div>
            <div class="mt-3 mb-4 my_right">
                <span class="my_small ">没有1More帐号？</span>
                <router-link to="/index" class="my_zc my_small">立即注册</router-link></div>
            <div class="">
                <span class="my_small my_left">您也可以用这些方式登录</span>
                <a href="https://www.sina.com.cn/" >
                    <img src="img/qtdl1.png" alt="" class="my_right my_position">
                </a>
            </div>
        </form>
    </div>
</template>

<script>
    export default {
        data:function(){
            return {}
        }
    }
</script>

<style>
#my_lv{
    width: 370px;
    margin: 100px auto 230px;
}
#my_lv .my_margin{
    position: relative;
    top:100px;
    width: 100%;
}
#my_lv .m_small{
    font-size: 2px;
    color:black;
}
#my_lv .m_hover:hover{
    color:black;
    text-decoration: none;
}
#my_lv .my_top{
    height: 400px;
}
#my_lv .my_bottom{
    height: 560px;
}
#my_lv img{
    color:#444 !important;
}
#my_lv .my_position{
    position: relative;
    top:-18px;
}
</style>
