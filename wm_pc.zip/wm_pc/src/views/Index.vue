<template>
    <div id="main">
        <!--指示符-->
      <div class="carousel my_bodyer" id="myCarousel" data-ride="carousel">
          <!--指示符-->
          <ol class="carousel-indicators">
              <li class="active " data-target="#myCarousel" data-slide-to="0"></li>
              <li class="active" data-target="#myCarousel" data-slide-to="1"></li>
              <li class="active" data-target="#myCarousel" data-slide-to="2"></li>
              <li class="active" data-target="#myCarousel" data-slide-to="3"></li>
              <li class="active" data-target="#myCarousel" data-slide-to="4"></li>
          </ol>
          <!--轮播图片-->
          <div class="carousel-inner">
                <div class="carousel-item"  :class='item.cid==1?"active":""'  v-for="(item) in products" :key="item.cid" >
                    <router-link :to="item.href|getLid">
                        <img :src="item.img" alt="" class="img-fluid">
                    </router-link>
                </div>
          </div>  
      </div>
        <!--左右箭头-->
      <a href="#myCarousel" class="carousel-control-prev" data-slide="prev">
              <img src="img/index/sprite.png" alt="">
      </a>
      <a href="#myCarousel" class="carousel-control-next" data-slide="next">
              <img src="img/index/sprite11.png" alt="">
      </a>
      <div class="row my_bodyer mr-0">
          <div class="col-6 p-0"><img src="img/index/body-1.jpg" alt="" class="img-fluid"></div>
          <div class="col-6 p-0"><img src="img/index/body-2.jpg" alt="" class="img-fluid"></div>
      </div>
      <div class="row my_bodyer mr-0">
          <div class="col-6 p-0"><img src="img/index/body-3.jpg" alt="" class="img-fluid"></div>
          <div class="col-6 p-0"><img src="img/index/body-4.jpg" alt="" class="img-fluid"></div>
      </div>    
    </div>
</template>

<script>
    import Vue from 'vue'
    import '../../public/css/base.css'
    Vue.filter("getLid",function(val){
        var lid = val.split("=")[1];
        return "/details/"+lid
    })
    export default {
        data:function(){
            return {
                products:[]
            }
        },
        mounted(){
            this.axios.get(
                "http://localhost:3000/index/getIndex"
            ).then(res=>{
                this.products= res.data.slice(0,5)
                console.log(this.products)
            })
        }
    }
</script>

<style scoped>
    #main>.carousel>.carousel-indicators li{
        position: relative;
        /*flex: 0 1 auto;*/
        width: 10px !important;
        height: 10px !important;
        margin-right: 3px;
        margin-left: 3px;
        border-radius: 50% !important;
        cursor: pointer;
    }
    #main>.my_bodyer{
        position: relative;
        top:-6px;
        left:0;
    }
</style>
