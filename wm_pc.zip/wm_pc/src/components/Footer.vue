<template>
   <footer id="footer">
      <div class="row ml-0 mr-0 pt-4">
          <div class="col-lg-2 mt-5 ">
              <img src="img/footer/homex_2_04.jpg" alt="" class="ml-5">
          </div>
          <div class="col-lg-8 mt-4 d-flex justify-content-md-around">
              <ul class="list-unstyled ">
                  <li class="mr-3 mb-1"><h6 class="mb-3">产品中心</h6></li>
                  <li class="mr-3 mb-1 text-center"><a href="#" class="my_gray my_size my_hover ">声学</a></li>
                  <li class="mr-3 mb-1 text-center"><a href="#" class="my_gray my_size my_hover ">智玩</a></li>
              </ul>
              <ul class="list-unstyled ">
                  <li class="mr-3 mb-1"><h6 class="mb-3">资讯中心</h6></li>
                  <li class="mr-3 mb-1  text-center"><a href="#" class="my_gray my_hover my_size">公司新闻</a></li>
                  <li class="mr-3 mb-1  text-center"><a href="#" class="my_gray my_hover my_size">行业新闻</a></li>
                  <li class="mr-3 mb-1  text-center"><a href="#" class="my_gray my_hover my_size">精彩视频</a></li>
                  <li class="mr-3 mb-1  text-center"><a href="#" class="my_gray my_hover my_size">技术分享</a></li>
              </ul>
              <ul class="list-unstyled ">
                  <li class="mr-3 mb-1"><h6 class="mb-3">关于我们</h6></li>
                  <li class="mr-3 mb-1 text-center"><a href="#" class="my_size my_hover my_gray">关于1more</a></li>
                  <li class="mr-3 mb-1 text-center"><a href="#" class="my_size my_hover my_gray">加入我们</a></li>
                  <li class="mr-3 mb-1 text-center"><a href="#" class="my_size my_hover my_gray">联系我们</a></li>
              </ul>
              <ul class="list-unstyled " >
                  <li class="mr-3 " ><h6 class="mb-3">关注我们</h6></li>
                  <li class="mr-3 text-center" ><a href="#" class="my_gray my_hover my_size">新浪微博</a></li>
              </ul>
          </div>
          <div class="col-lg-2">
              <ul class="list-unstyled">
                  <li class="my_gray mb-3 text-center">客服热线</li>
                  <li class="mb-1 text-center">400-992-0909</li>
                  <li class="mb-1 text-center">0755-86574095</li>
                  <li class="mb-1 text-center">
                      <button class="my_color my_cursor">在线客服</button></li>
              </ul>
              <select name="" id="" class="my_control1  mt-0">
                  <option value="chinese">China</option>
                  <option value="japanese">Japan</option>
                  <option value="smida">한국</option>
                  <option value="english">English</option>
                  <option value="Global" selected>global</option>
              </select>
          </div>
      </div>
        <ul class="list-unstyled d-flex justify-content-center"  >
            <li class="mr-2"><img src="img/footer/tmall.jpg" alt=""><p><a href="" class="my_small my_gray my_hover">1MORE天猫旗舰店</a></p></li>
            <li class="mr-2"><img src="img/footer/jd.jpg" alt=""><p><a href="" class="my_small my_gray my_hover">1MORE京东旗舰店</a></p></li>
            <li class="mr-2"><img src="img/footer/shundian.jpg" alt=""><p><a href="" class="my_small my_gray my_hover">1MORE顺电旗舰店</a></p></li>
        </ul>
        <hr class="mt-1">
        <p class="text-center my_small">&copy;2013-2017&nbsp;万魔声学科技有限公司 版权所有&nbsp;粤ICP备13074094号-1</p>
        <p class="text-center my_small">万魔声学科技有限公司对本网站所有图片与资料拥有所有权,如未经允许盗链或下载使用,必追究相关法律责任</p>
   </footer>
</template>

<script>
    export default {

    }
</script>

<style scoped>
#footer{
    background: #E8E8E8;
    width: 100%;
    padding: 0;
    margin: 0;
}
#footer>.row{
    margin-top: -5px;
}
@media screen and (min-width:992px){
#footer>div{
        margin: 0 auto;
    }
}
#footer .my_ml{
    margin-left:100px;
}
#footer .my_color{
    background: #FF5138;
}
#footer .my_size{
    font-size: 12px;
    color: #433434;
}
#footer .my_gray{
    color:#777;
}
#footer .my_pr{
    padding-right: 120px;
}
#footer .my_control1{
    display: block;
    width: 176px;
    height: 40px;
    padding-left:14px;
    font-size: 1rem;
    line-height: 58px;
    color: #495057;
    background-color: #fff;
    border: 1px solid #eee;
    border-radius: 0.25rem;
    cursor: pointer;
}
#footer .my_cursor{
    cursor: pointer;
}
</style>
