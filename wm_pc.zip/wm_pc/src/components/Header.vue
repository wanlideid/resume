<template>
    <header id="header">
        <div class="row m-0">
                <div class="col-lg-2 col-md-4 pt-2">
                    <router-link to="/index" class="my_ml"><img src="img/header/logo.png" alt=""></router-link>
                </div>
                <div class="col-lg-8 col-md-4 pt-4 ">
                    <ul class="list-unstyled d-flex nav_ml">
                        <li class="ml-5"><router-link to="/products" class="my_white my_hover my_size" @click="search()">产品</router-link></li>
                        <li class="ml-5"><a href="#" class=" my_white my_hover my_size">咨询</a></li>
                        <li class="ml-5"><a href="#" class=" my_white my_hover my_size">体验店</a></li>
                        <li class="ml-5"><a href="#" class=" my_white my_hover my_size">服务</a></li>
                        <li class="ml-5"><a href="#" class=" my_white my_hover my_size">社区</a></li>
                        <li class="ml-5"><input type="text" class="my_input" placeholder="请输入你想搜索的商品" v-model="kwords" @keyup.13="search()"></li>
                    </ul>  
                </div>
                <div class="col-lg-2 col-md-4 pt-4" >
                    <nav class="list-unstyled d-flex" id="signout" v-if="!islogin">
                                <router-link to="/login" class="my_white my_small my_hover" @click.prevent="signin()">
                                    <span id="btn_login">登录</span>
                                </router-link>
                                <b class="ml-1 mr-1 my_gray">|</b>
                                <router-link to="/register" class="my_white my_small my_hover" @click="register()">
                                    <span id="btn_register">注册</span>
                                </router-link>
                                <router-link to="/cart" class="ml-1 mr-1">
                                        <img src="img/header/newcart.png" alt="" class="mb-2">
                                </router-link>    
                                <router-link to="/cart" class="my_white my_hover my_small">购物车</router-link>
                    </nav>
                    <nav class="list-unstyled d-flex" id="signin" v-else>
                        <a href="" class="my_white my_small my_hover" >
                            <span id="uname" v-text="uname"></span>
                        </a>
                        <b class="ml-1 mr-1 my_gray">|</b>
                        <a href="" class="my_white my_small my_hover" id="btnSignout" @click.prevent="signout()">注销</a>
                        <a href="cart.html" class="ml-1 mr-1">
                            <img src="img/header/newcart.png" alt="" class="mb-2">
                        </a>    
                        <router-link to="/cart" class="my_white my_hover my_small">购物车</router-link> 
                    </nav>
                </div>
            </div>
</header>
</template>

<script>
    export default {
        data:function(){
            return  {kwords:"",islogin:false,uname:""}
        },
        mounted(){
            this.axios.get("http://localhost:3000/user/islogin").then(res=>{
                if(res.data.ok==0)
                    this.islogin=false
                else{
                    this.islogin=true
                    this.uname = res.uname
                }         
            })
        },
        methods:{
            search(){
              if(this.kwords)   
                this.$router.push('/products/'+this.kwords)
                this.$router.go(0)
            },
            signin(){
              var path = this.$route.path;
              //console.log(path)
              if(path=="/"){
                  path="/index"
              }
              this.$router.push("/login/"+encodeURIComponent(path.slice(1)))
            },
            signout(){
                this.axios.get("http://localhost:3000/user/signout").then(res=>{
                    this.islogin=false
                })
            },
            register(){
                var path = this.$route.path;
                this.$router.push("/login")
            }
        }
    }
</script>

<style scoped>
    #header div{
        background: #0F0B0C;
        width: 100%;
        height: 80px;
    }
    #header .my_ml{
        margin-left: 50px !important;
    }
    #header .my_size{
        font-size: 18px !important;

    }
    #header .nav_ml{
        margin-left: 0 !important;
    }
    #header .my_white{
        color:white;
    }
    #header a{
        color:white;
    }
    #header a:hover{
        color: red;
        text-decoration: none;
    }
    #header ul{
        margin:0;
        padding:0;
        list-style-type:none;
    }
    #header .li1:hover .ul_1{
        display:block;
        color:white;
        position:absolute;
    }
    #header .ul1{
        display:none;
    }
    #header .ul1 li{
        clear:left;
    }
    .hide{
        display: none !important;
    }
    .show{
        display: block !important;
    }
    #signout{
        width: 200px;
    }
    #header .my_input{
        width: 300px;
        height: 35px;
        padding-left: 20px;
        font-size: 1px;
        line-height: 30px;
        color: #495057;
        background-color: #fff;
        border: 1px solid #eee;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }



</style>

