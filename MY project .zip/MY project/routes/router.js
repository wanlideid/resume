const express=require("express");
var router=express.Router();

router.get('login',(req,res)=>{
  
});

module.exports=router;