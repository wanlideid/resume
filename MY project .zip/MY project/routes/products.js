const express = require("express");
const pool = require("../pool")
var router = express.Router();

router.get("/getProducts",(req,res)=>{
    var kwords = req.query.kwords;
    var arr = kwords.split(" ");
    for(var i=0;i<arr.length;i++){
        arr[i]=`title like '%${arr[i]}%'`
    }
    var where=" where "+arr.join(" and ")
    var output={ pageSize:9 } //每页9个商品
    output.pno=req.query.pno;
    var sql="SELECT *,( SELECT md from wm_laptop_pic where pid=lid limit 1 ) as md FROM wm_laptop";
    pool.query(sql+where,[],(err,result)=>{
        if(err) console.log(err);
        output.count = result.length;
        output.pageCount=Math.ceil(output.count/output.pageSize);
        output.products=result.slice(output.pno*9,output.pno*9+9);
        res.writeHead(200,{
            "Content-Type":"application/json;charset=utf-8",
            "Access-Control-Allow-Origin":"*"
        })
        res.write(JSON.stringify(output))
        res.end();
    })
})
module.exports = router;