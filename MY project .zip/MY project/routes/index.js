const express = require("express");
const router = express.Router();
const pool = require("../pool");
        

router.get("/getIndex",(req,res)=>{
    var sql = `SELECT * FROM wm_index_carousel`;
    pool.query(sql,[],(err,result)=>{ 
        if(err) console.log(err);  
        res.writeHead(200,{
            "Content-Type":"application/json;charset=UTF-8",
            "Access-Control-Allow-Origin":"*"
        })
        res.write(JSON.stringify(result));
        res.end()
    })
})

module.exports=router;