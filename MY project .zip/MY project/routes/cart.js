const express = require("express");
const pool = require("../pool");
const router = express.Router();

router.get("/getCart",(req,res)=>{
    var lid = req.query.lid;
    var count = req.query.count;
    var uid = req.session.uid;
    var sql =`select * from wm_shoppingcart_item where user_id=? and product_id=?`;
    pool.query(sql,[uid,lid],(err,result)=>{
        if(result.length==0){
            var sql=`INSERT into wm_shoppingcart_item values(null,?,?,?,0)`;
            pool.query(sql,[uid,lid,count],(err,result)=>{
                if(err) console.log(err);
                res.end();
            })
        }else{
            var sql = `update  wm_shoppingcart_item set count=count+?  where user_id=? and product_id=?`;
            pool.query(sql,[count,uid,lid],(err,result)=>{
                 if(err) console.log(err)
                 res.end()
            })
        }
    })
    
})
router.get("/items",(req,res)=>{
    var uid = req.session.uid;
    var sql = `SELECT *,(
        select md from wm_laptop_pic
        where pid=product_id
        limit 1
      )as md 
      FROM wm_shoppingcart_item 
      inner join wm_laptop on product_id=lid
      where user_id=?`
    pool.query(sql,[uid],(err,result)=>{
        if(err) console.log(err);
        res.writeHead(200);
        res.write(JSON.stringify(result));
        res.end();
    })  
})
router.get("/update",(req,res)=>{
    var iid = req.query.iid;
    var count = req.query.count;
    if(count>0){
    var sql=`update  wm_shoppingcart_item set count=? where iid=?`;
        pool.query(sql,[count,iid],(err,result)=>{
            if(err) console.log(err);
            res.end();
        })
    }else{
    var sql=`delete from wm_shoppingcart_item where iid=?`;
        pool.query(sql,[iid],(err,result)=>{
            if(err) console.log(err);
            res.end();
        })
    }
})

module.exports = router;