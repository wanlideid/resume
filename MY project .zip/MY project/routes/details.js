const express = require ("express");
const pool = require("../pool");
const router = express.Router();

router.get("/getDetails",(req,res)=> {
    var lid = req.query.lid;
    var sql1 = "SELECT * from wm_laptop WHERE lid=?";  //查找当前商品
    var sql2 = "SELECT * from wm_laptop_pic WHERE pid=?";  //查找当前商品图片
    var sql3 = "SELECT lid,spec from wm_laptop WHERE family_id=(SELECT family_id from wm_laptop WHERE lid=?)";//查找当前商品规格
    var output = {
        products: {},
        pics: [],
        spec: []
    }
    Promise.all([
        new Promise(function (open){
             pool.query(sql1, [lid], (err, result) => {
                if (err) console.log(err);
                output.products = result[0];
                open();
             })
        }),
         new Promise(function (open){
             pool.query(sql2, [lid], (err, result) => {
                if (err) console.log(err);
                output.pics = result;
                open();

            })
         }),
         new Promise(function (open) {
             pool.query(sql3, [lid], (err, result) => {
                 if (err) console.log(err);
                 output.spec = result;
                 open();
             })
         })
]).then(function(){
        res.writeHead(200, {
            "Content-Type": "application/json;charset=utf8",
            "Access-Control-Allow-Origin": "*"
        })
        res.write(JSON.stringify(output));
        res.end();
    })
});
module.exports=router;