$(function(){
    $("img").on("click",function () {
        var $img=$(this);
        var i=parseInt($img.attr("alt"))
        i++;
        if(i>4) i=1;
        $img.attr({
            "src":`img/${i}.jpg`,
            "alt":i
        })
    })
    $("#cpwd").on("blur",function(){
        var upwd=$("#upwd").val();
        var cpwd=$("#cpwd").val();
        if(cpwd!=""){
            if(upwd==cpwd){
                $(".showCpwd").html("密码一致");
            }else{
                $(".showCpwd").html("密码不一致，请重新输入");
            }
        }else{
            $(".showCpwd").html("密码不能为空");
        } 
    })
    $("#button").click(function(e){
        e.preventDefault();
        var uname = $("input.uname").val();
        var upwd = $("input.upwd").val();
        var cpwd = $("input.cpwd").val();
        var phone = $("input.phone").val();
        (async function(){
            var res=await $.ajax({
                url:"http://localhost:3000/user/register",
                type:"post",
                data:{uname,upwd,phone},
                dataType:"json"
            })
            if(res.ok==2){
                $("showUname").html("用户名已存在");
            }else if(res.ok==3){
                if(location.search.startsWith("?back=")){
                    var url = location.search.slice(6)
                }else{
                    var url = "index.html";
                }
                location.href=url;
            }
        })();
    })

})