$(function(){
    if(location.search.indexOf("?pid=")!=-1){
        var id=location.search.split("=")[1];
    }
    (async function(){
        var res=await $.ajax({
            url:"http://localhost:3000/details/getDetails",
            type:"get",
            data:"lid="+id,
            dataType:"json"
        })
        var {products,pics,spec} = res;
        var {title,subtitle,price} = products;
        $("#divDetails").children(".title").html(title);
        $("#divDetails").children(".subtitle").html(subtitle);
        $("#divDetails").children(".price").children(".pro_price").children("span").html("￥"+price.toFixed(2));
        var html="";
        for (var s of spec){
            html+=`<a href="product_details.html?pid=${s.lid}" class="my_color ${id==s.lid?'active':''}">${s.spec}</a>`;
            $("#divDetails").children(".spec").children("div").html(html);
        }
        var html="";
        for(var p of pics){
            html += `<img src="${p.md}" alt=""  >`;
            $("#wo").html(html);
        }
        $("#divDetails").on("click","img",function(){
            var $img=$(this)
            var $input=$("img").parent().parent().children(".car_2").children("input");
            var n = $input.val();
            var $className=$img.attr("className");
            if($className=="add"){
                n++;
            }else if(n>1){
                n--;
            }
            $input.val(n);
        })
          
    })()
    $("#divDetails").on("click","button",function(){
        var $button = $(this);
        var lid="";
        lid=id;
        var count = "";
        var $input=$("img").parent().parent().children(".car_2").children("input");
        var n = $input.val();
        count = 1;
        $.ajax({
            url:"http://localhost:3000/cart/getCart",
            type:"get",
            data:{lid,count},
            dataType:"json"
        })
        alert("添加成功");
    })    
})