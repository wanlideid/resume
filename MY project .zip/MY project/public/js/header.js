$  (function(){
    $("<link rel='stylesheet' href='../css/header.css'>").appendTo("head");
    $.ajax({
        url:"http://localhost:3000/head.html",
        type:"get",
        success(res){
            $("#header").replaceWith(res);
            
            $("#btn_login").click(function(e){
                e.preventDefault();
                location.href=
                  "login.html?back="+location.href;
              })
              $("#btn_register").click(function(e){
                e.preventDefault();
                location.href=
                  "registers.html?back="+location.href;
              })
             
              var $input = $("input.my_input");
              $input.keyup(function(e){
                if(e.keyCode=="13"){
                  var kw =$input.val().trim();
                  if(kw!==""){
                      location.href = `products.html?kwords=${kw}`;
                  }
                }
              })
              if(location.search.indexOf("kwords")!=-1){
                var kwords = decodeURI(location.search.split("=")[1])
                $input.val(kwords)
              }   
            $.ajax({
                url:"http://localhost:3000/user/islogin",
                type:"get",
                dataType:"json",
                success(res){
                    if(res.ok==0){
                        $("#signout").addClass("show").next().addClass("hide");
                    }else{
                        $("#uname").html(res.uname);
                        $("#signout").addClass("hide").next().addClass("show");
                    }   
                }
            })
            $("#btnSignout").click(function(){
                $.ajax({
                    url:"http://localhost:3000/user/signout",
                    type:"get",
                    success(){
                        location.reload();
                    }
                }) 
            }) 
            
        }
    })
})