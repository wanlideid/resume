$(function(){
    if(location.search.indexOf("kwords=")!=-1){
        var kwords = decodeURI(location.href.split("=")[1]);
        var pno = 0;
        function loadPage(no=0){
            pno=no;
        $.ajax({
                url: "http://localhost:3000/products/getProducts",
                type: "get",
                data: {kwords, pno},
                dataType: "json",
                success(output) {
                    var {products,pageCount} = output;
                    var html = "";
                    for (var p of products) {
                        var {lid, price, title, md} = p;
                        html += `
                    <div class="my_product mr-3">
                     <div>
                        <a href="product_details.html?pid=${lid}" >
                            <img src="${md}" alt="">
                        </a> 
                        </div>
                        <div class="pl-3 my_size">
                            ${title}
                        </div>
                        <div class="mt-4">
                            <span>RMB:
                                <i class="my_price ml-2">${price.toFixed(2)}</i>
                            </span>
                            <div class="float-right">
                                <a href="cart.html?pid=${lid}" data-lid="${lid}">
                                    <img src="img/products/cart.jpg" alt="" class="">
                                </a>
                            </div>
                        </div>
                        <div class="my_fl mt-3">
                            <img src="img/products/zan.jpg" alt="">
                            "("<span>0</span>")"
                        </div>
                    </div>
                    </div>`
                    }
                    var $plist=$("#plist");
                    $plist.html(html);

                    var html = "";
                        for(var i=1;i<=pageCount;i++){
                            html+=`<li class="page-item ${i==pno+1?'active bg-primary':''}"><a class="page-link " href="#">${i}</a></li>`
                        }
                        var $ul=$("#plist").next().find("nav>ul");
                        $ul.children(":not(:first-child):not(:last-child)").remove();
                        $ul.children().first().after(html);
                        if(pno==0){
                            $ul.children().first().addClass("disabled")
                        }else{
                            $ul.children().first().removeClass("disabled")
                        }
                        if(pno==pageCount-1){
                            $ul.children().last().addClass("disabled")
                        }else{
                            $ul.children().last().removeClass("disabled")
                        }
                    }
                })
        }
        loadPage();
        var $ul=$("#plist").next().find("nav>ul");
            $ul.on("click","a",function(e){
                e.preventDefault();
                var $a= $(this);
                if(!$a.parent().is(".disabled,.active")){
                    console.log($a.parent().is(":first-child"));
                   if($a.parent().is(":first-child"))
                     var  no = pno-1;
                   else if($a.parent().is(":last-child"))
                     var  no = pno+1
                   else
                     var  no = $a.html()-1;
                   loadPage(no);
                }
            });
    };
    
})