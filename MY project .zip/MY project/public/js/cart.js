$(function(){
    async function loadCart(){
        var res =await $.ajax({
                url:"http://localhost:3000/user/islogin",
                type:"get",
                dataType:"json"
            });
            if(res.ok==0){
                alert("暂未登录，请先登录");
                location.href="login.html";
            }else{
             var res= await $.ajax({
                    url:"http://localhost:3000/cart/items",
                    type:"get",
                    dataType:"json"
                });
                var html="",total=0;
                
                for(var item of res){
                   var {iid,product_id,title,price,md,count} =item;
                   total +=price*count;
                    html+=`<div class="content_car4">
                            <div class="content_car4_1">
                            <div class="content_car4_1_1">
                                <img src="" alt="">
                            </div>
                            <div class="content_car4_1_2">
                                <a>${title}</a>
                            </div>
                            </div>
                            <div class="content_car4_3">
                                <span>${price}</span>
                            </div>
                            <div class="content_car4_4">
                            <div class="content_car4_4_1">
                                    <img src="img/cart/gouwuche_16.jpg" alt="" data-iid=${iid} class="reduce">
                                
                            </div>
                            <div class="content_car4_4_2">
                                <input type="text" value="${count}" >
                            </div>
                            <div class="content_car4_4_3">
                                    <img src="img/cart/gouwuche_16-06.jpg" alt="" data-name="add" data-iid=${iid}>
                            </div>
                            </div>
                            <div class="content_car4_5">
                                <span>${(price*count).toFixed(2)}</span>
                            </div>
                            <div class="content_car4_6">
                                <a href="">×</a>
                            </div>
                    </div>`
                }
                $("#car_my").children(".content_car1").children(".content_car3").next().html()
                $("#car_my").children(".content_car1").children(".content_car3").next().html(html);
                
                $("#my_click").siblings(".content_car5").children(":first-child()").children("span").html(`￥&nbsp;${total.toFixed(2)}`)
                
            }      
    }
    loadCart();
    
    $("#my_click").on("click","img",function(e){
        e.preventDefault();
        // console.log($("img.add"));
         var $img=$(this);
         (async function(){
            var iid = $img.attr("data-iid");
            var $input=$img.parent().siblings(".content_car4_4_2").children("input");
            var count = $input.val();
            var $name=$img.attr("data-name");
            if($name=="add"){
                count++; 
            }else if(count>0){
                count--;
                
            }
           $input.val(count)
            if(count==0){
                if(!confirm("是否删除商品"))
                    return;
                    location.reload();
            } 
           await $.ajax({
                 url:"http://localhost:3000/cart/update",
                 type:"get",
                 data:{iid,count}
             })
            
        })()
        //loadCart();
        location.reload();     
    })

})