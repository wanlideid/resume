$.ajax({
    url:"http://localhost:3000/index/getIndex",
    type:"get",
    dataType:"json",
    success(res){
        var html="";
        for(var p of res.slice(0,5)){
            var {cid,href,img,title}=p;
            html += `
                    <div class="carousel-item">
                    <a href="${href}"><img src="${img}" alt="" class="img-fluid"></a>
                </div>
            `;
        }
        var divCard = document.querySelector("#myCarousel>.carousel-inner");
        divCard.innerHTML=html;
        $("#myCarousel>.carousel-inner>div:first-child").addClass("active");
    }
})