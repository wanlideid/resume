//app.js
//1:加载模块
const express = require("express");
const pool  = require("./pool");
//2:创建express对象
var app = express();
//服务器node.js 允许跨域访问配置项
//2.1:引入跨域模块   

//2.2:配置允许哪个程序跨域访问 脚手架   11:16

//3:指定静态目录
//服务器指定目录 绝对路径 出错
app.use(express.static(__dirname+"/public"));

//4:绑定监听端口
app.listen(3000);
//功能一:学子商城首页图片轮播
//GET /imagelist   json
/*app.get("/imagelist",(req,res)=>{
  var obj = {
    list: [
    {id:1,img_url:"http://176.51.1.108:3000/img/banner1.png"},
    {id:2,img_url:"http://176.51.1.108:3000/img/banner2.png"},
    {id:3,img_url:"http://176.51.1.108:3000/img/banner3.png"},
    {id:4,img_url:"http://176.51.1.108:3000/img/banner4.png"}], 
img: [
{id:1, icon_url:"http://176.51.1.108:3000/img/grid-01.png",title:"美食"},
{id:2, icon_url: "http://176.51.1.108:3000/img/grid-02.png", title: "桑拿" },
{id:3, icon_url: "http://176.51.1.108:3000/img/grid-03.png", title: "婚礼" },
{id:4, icon_url: "http://176.51.1.108:3000/img/grid-04.png", title: "ktv" },
{id:5, icon_url: "http://176.51.1.108:3000/img/grid-05.png", title: "找工作" },
{id:6, icon_url: "http://176.51.1.108:3000/img/grid-06.png", title: "汽车保养" },
{id:7, icon_url: "http://176.51.1.108:3000/img/grid-07.png", title: "租房" },
{id:8, icon_url: "http://176.51.1.108:3000/img/grid-08.png", title: "装修" },
{id:9, icon_url: "http://176.51.1.108:3000/img/grid-09.png", title: "更多" },]
  };
  res.send(obj)
});*/


//功能二:分页显示:新闻分页
app.get("/newslist1",(req,res)=>{
  //1:参数  当前页码  页大小(一页显示几行数据)
  var pno = req.query.pno;            //2
  var pageSize = req.query.pageSize;  //5
  //2:sql
  //2.1:查找总记录数->转换总页数  15->3
  var sql = "SELECT count(id) as c FROM xz_news";
  var obj = {};      //保存发送客户端数据
  var progress = 0;  //进度
  pool.query(sql,(err,result)=>{
      console.log(result)
      if(err) throw err;
      var c = Math.ceil(result[0].c/pageSize);
      obj.pageCount = c;
      progress+=50;
      if(progress==100){
        res.send(obj);
      }
  });
  //2.2:查找当前页内容           中间5行
  var sql = " SELECT id,title,img_url,ctime,point";
     sql += " FROM xz_news";
     sql += " LIMIT ?,?";
  var offset = parseInt((pno-1)*pageSize);   
  //计算分页偏移量
  pageSize = parseInt(pageSize)
  pool.query(sql,[offset,pageSize],(err,result)=>{
      if(err)throw err;
      //console.log(result);
      obj.data = result;
      progress+=50;
      if(progress==100){
        res.send(obj);
      }
  })
  //3:结果格式
});
//功能三:发送脚手架新闻详细
app.get("/newsinfo",(req,res)=>{
   var obj = {
     title:"北京房价下降，白菜价",
     content:"16万/平 快快买啊!!!!!!"
    };
   res.send(obj);
});

//功能四:用户发表评论
const qs = require("querystring");
app.post("/postcomment",(req,res)=>{
   //为req对象绑定事件data   10:45
   req.on("data",(buf)=>{
     var str = buf.toString();  //1:将参数转字符串
     var obj = JSON.parse(str); //2:将参数转对象
     var msg = obj.msg;         
     var nid = parseInt(obj.nid);
     var sql = "INSERT INTO xz_comment(content,user_name,ctime,nid) VALUES(?,'匿名',now(),?)";
     pool.query(sql,[msg,nid],(err,result)=>{
       if(err)throw err;
       res.send({code:1,msg:"添加成功"});
     })
   })
})



//功能五:用户获取指定新闻编号所有评论
app.get("/getComment",(req,res)=>{
  //获取指定新闻编号  
  var nid = parseInt(req.query.id);
  var pno = req.query.pno;            
  var pageSize = req.query.pageSize;  
  var sql = " SELECT count(id) as c FROM xz_comment";
  sql +=" WHERE nid = ?";
  var obj = {};      //保存发送客户端数据
  var progress = 0;  //进度
  pool.query(sql,[nid],(err,result)=>{
      if(err)throw err;
      var c = Math.ceil(result[0].c/pageSize);
      obj.pageCount = c;
      progress+=50;
      if(progress==100){
        res.send(obj);
       }
    });
    //2.2:查找当前页内容
  var sql = " SELECT id,content,ctime,user_name";
     sql += " FROM xz_comment";
     sql += " WHERE nid = ?"
     sql += " ORDER BY id DESC";//降序排列
     sql += " LIMIT ?,?";
  var offset = parseInt((pno-1)*pageSize);   
  pageSize = parseInt(pageSize)
  pool.query(sql,[nid,offset,pageSize],(err,result)=>{
     if(err)throw err;
      obj.data = result;
      progress+=50;
      if(progress==100){
      res.send(obj);
      }
  })
})


//功能六 ：返回商品详细信息
//[id;title;now;old;商号]
//参数id
app.get("/goodsinfo",(req,res)=>{
  var id = req.query.id;
  var obj =
   {id:id,title:"华为2000",now:9999,old:88888,pid:"9527"};
  res.send(obj);
});

//功能七:购物车数据列表    
//组件发送ajax请求获取并显示数据
app.get("/shopCart",(req,res)=>{
var obj = [];
obj.push({id:1,title:"华为p10",price:3999,count:2})
obj.push({id:2,title:"华为p11",price:4999,count:1})
obj.push({id:3,title:"华为p12",price:5999,count:1})
res.send(obj);
})

//功能八:将商品信息添加至购物车
//-INSERT INTO xz_cart VALUES();
/*app.get("/addCart",(req,res)=>{
  //1:参数  商品id 商品数量
    //1.1：获取参数
    var pid = req.query.pid;
    var count = req.query.count;
    //1.2: 创建正则表达式验证  一定做
    //所有用户参数都需要验证 js第一次 node.js第二次
    //安全 
    var reg = /^[0-9]{1,}$/;     //正则表达式
    if(!reg.test(pid)){          //如果参数验证失败
      res.send({code:-1,msg:"商品编号参数有误"});
      return;               //输出错误信息并停止
    }
    if(!reg.test(count)){
      res.send({code:-2,msg:"商品数量参数有误"});
      return;               //输出错误信息并停止
    }
    //1.3: 如果验证失败返回
    //2:连接数据库
    //3:返回成功值
    res.send({code:1,msg:"添加成功"});
})*/


app.get("/login",(req,res)=>{
  //1:参数 2 uname upwd
  var uname = req.query.uname;
  var upwd = req.query.upwd;
  //2:正则表达式验证 
  //3:sql 
  var sql = " SELECT count(id) as c FROM xz_user2";
      sql +=" WHERE uname=? AND upwd = md5(?)";
  pool.query(sql,[uname,upwd],(err,result)=>{
        if(err)throw err;
        if(result[0].c==0){
          res.send({code:-1,msg:"登录失败"});
        }else{
          res.send({code:1,msg:"登录成功"});
        }
  })

});

app.get("/test01",(req,res)=>{
  var id = req.query.id;
  var age = req.query.age;
  res.send(id+1+age);
})

app.get("/newslist",(req,res)=>{
  var obj = [
    {id:1,ctime: "2018-9-10", img_url:"http://176.51.1.108:3000/img/banner1.png",title:"手机盛典1",desc:"手机中的拖拉机1"},
    {id:2,ctime: "2018-9-11", img_url:"http://176.51.1.108:3000/img/banner2.png",title:"手机盛典2",desc:"手机中的拖拉机2"},
    {id:3,ctime: "2018-9-12", img_url:"http://176.51.1.108:3000/img/banner3.png",title:"手机盛典3",desc:"手机中的拖拉机3"},
    {id:4,ctime: "2018-9-13", img_url:"http://176.51.1.108:3000/img/banner4.png",title:"手机盛典4",desc:"手机中的拖拉机4"}
  ]
  res.send(obj);
})

app.post("/postProduct",(req,res)=>{
  req.on("data",(buff)=>{
    var obj = qs.parse(buff.toString());
    console.log(obj);
    var pno = obj.pno;
    var price = obj.price;
    res.send({code:1,msg:":"+pno+":"+price})
  })
})

app.get("/getImage",(req,res)=>{
  var obj ={
    list:[{id:1,img_url:"img/index/carousel-1.jpg"},
    {id:2,img_url:"img/index/carousel-2.jpg"},
    {id:3,img_url:"img/index/carousel-3.jpg"},
    {id:4,img_url:"img/index/carousel-4.jpg"},
  ],
  data:[
    {id:1,icon_url:"img/products/product_0.jpg",title:"天声好色"},
    {id:2,icon_url:"img/products/product_4.jpg",title:"时尚配色"},
    {id:3,icon_url:"img/products/product_8.jpg",title:"高清降噪"},
    {id:4,icon_url:"img/products/product_13.jpg",title:"全部商品"},
    {id:5,icon_url:"img/products/product_10.jpg",title:"电竞蓝牙"},
    {id:6,icon_url:"img/products/product_15.jpg",title:"生活美学"}
  ]
}
  res.send(obj)
})

app.get("/imagelist",(req,res)=>{
  var id = req.query.id;
  //console.log(id)
  var sql=`select * from wm_laptop where family_id=?`;
  pool.query(sql,[id],(err,result)=>{
    if(err) throw err;
    //console.log(result)
    res.send(result);
  })
})

app.get("/getKword",(req,res)=>{
  var kword = req.query.kword;
  //console.log(kword);
  var arr = kword.split(" ");
  for(var i=0;i<arr.length;i++){
    arr[i] = `title like '%${arr[i]}%'`
  }
  var where = ' where ' + arr.join(' and ');
  var sql = `select *,(select md from wm_laptop_pic where laptop_id=lid limit 1) as md from wm_laptop`;
  pool.query(sql+where,[],(err,result)=>{
    if(err) throw err;
    res.send(result);
  })
})

app.get("/shopList",(req,res)=>{
  var pno = req.query.pno;
  var pageSize = req.query.pageSize;
  var id = req.query.id;
  //console.log(pno)
  //console.log(pno,pageSize)
  var sql = `select count(lid) as c from wm_laptop`;
  var obj = {};
  var progress = 0;
  pool.query(sql,[],(err,result)=>{
    //console.log(result[0].c)
    if(err) throw err;
    var c = Math.ceil(result[0].c/pageSize)
      obj.pageCount = c;
    //console.log(obj.pageCount)
    progress +=50;
    if(progress ==100){
       res.send(obj)
    }
  });
  if(id==4){
    var sql = `select * from wm_laptop limit ?,?`;
    var offset = parseInt((pno-1)*pageSize);
    pageSize = parseInt(pageSize)
    console.log(offset,pageSize)
    pool.query(sql,[offset,pageSize],(err,result)=>{
      if(err) throw err;
      obj.data = result;
      
      //console.log(result)
      progress +=25;
      if(progress == 75){
        //console.log(progress)
        res.send(obj)
      }
    })
  }else{
    var sql = `select lid,title,price from wm_laptop limit ?,?`;
    var offset = parseInt((pno-1)*pageSize);
    pageSize = parseInt(pageSize)
    //console.log(pageSize)
    pool.query(sql,[offset,pageSize],(err,result)=>{
      if(err) throw err;
      obj.data = result;
      //console.log(obj.data)
      progress += 50;
      if(progress==100){
        res.send(obj)
      }
    })
  }
  
})

app.get("/detailsImg",(req,res)=>{
    var lid = req.query.lid;
    //console.log(id)
    var sql=`select * from wm_laptop where lid=?`;
    pool.query(sql,[lid],(err,result)=>{
      if(err) throw err;
      //console.log(result)
      res.send(result);
    })
})

app.get("/addCart",(req,res)=>{
  var lid = req.query.lid;
  //console.log(lid)
  var uid = 1;
  count = 1;
  var sql = `select * from wm_shoppingcart_item where product_id=?`;
  pool.query(sql,[lid],(err,result)=>{
    if(err) throw err;
    if(result.length==0){
      var sql = `Insert into wm_shoppingcart_item values(null,?,?,?,0)`;
      pool.query(sql,[uid,lid,count],(err,result)=>{
        if(err) throw err;
        res.end();
      })
    }else if(count>0){
      var sql = `update wm_shoppingcart_item set count=count+? where product_id=? and user_id=?`;
      pool.query(sql,[count,lid,uid],(err,result)=>{
        if(err) throw err;
        res.end();
      })
    }
  })
})

app.get("/reduceCart",(req,res)=>{
  var lid = req.query.lid;
  //console.log(lid)
  var uid = 1;
  var count = 1;
      var sql = `update wm_shoppingcart_item set count=count-? where product_id=? and user_id=?`;
        pool.query(sql,[count,lid,uid],(err,result)=>{
          if(err) throw err;
          res.end();
        })
    })

app.get("/deleteCart",(req,res)=>{
  var lid = req.query.lid;
  var sql=`delete from wm_shoppingcart_item where product_id =?`;
  pool.query(sql,[lid],(err,result)=>{
    if (err) throw err;
    res.end();
  })
}) 
    
app.get("/items",(req,res)=>{
  var uid = 1;
  var sql = `select * from wm_shoppingcart_item inner join wm_laptop on product_id=lid where user_id=?`;
  pool.query(sql,[uid],(err,result)=>{
    if(err) throw err;
    res.send(result);
  })
})