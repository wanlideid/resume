// pages/product/product.js
const app = getApp()
Page({
  search(val){
    var kword = val;
    //console.log(kword);
    wx.request({
      url: 'http://176.51.7.234:3000/getKword',
      data: { kword },
      success: res => {
        console.log(res.data)
        this.setData({list:res.data})
      }
    })
  },
  handleJump(event){
    var lid = event.target.dataset.lid;
    //console.log(lid)
    wx.navigateTo({
      url: '/pages/details/details?lid='+lid
    })
  },
  /**
   * 页面的初始数据
   */
  data: {
    url:app.globalData.url,
    kword:"",
    list:[],
    pageIndex:0,
    pageSize:12,
    hasMore:true
  },
  loadMore(id) {
    wx.request({
      url: 'http://176.51.7.234:3000/shopList',
      data: {
        pno: ++this.data.pageIndex,
        pageSize: this.data.pageSize,
        id:id
      },
      success:(res) =>{
        //console.log(res)
        var listTem = this.data.list;
        //console.log(listTem)
        
        var list = res.data.data;
        //console.log(list)
        var pageCount = res.data.pageCount;
        console.log(list.length <this.data.pageSize)
        if(list.length<this.data.pageSize){
          this.setData({
            list: listTem.concat(list),
            hasMore: false
          })
        }else{
          this.setData({
            list: listTem.concat(list),
            hasMore:true,
            pageIndex:this.data.pageIndex+1
          })
        }
        
        if (this.data.hasMore == false) {
          wx.showToast({
            title: '我可是有底线的',
            icon: "none",
            duration: 1000
          })
        };
      }
    })
    wx.showLoading({
      title: '正在加载数据'
    })
    setTimeout(function () {
      wx.hideLoading()
    }, 1000)
  },
  getImg(id){
    wx.request({
      url: 'http://176.51.7.234:3000/imagelist',
      method:"get",
      data:{id:id},
      success:(res)=>{
        //console.log(res)
        this.setData({
          list:res.data
        })
      }
    })
  },
  handleSearch(e){
    //const that = this;
    const val = e.detail.value;
    // 
    this.search(val)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad:function(options){
    console.log(options)
    var id = options.id;
    if(id==4){
      this.loadMore(id)
      
    }else{
      this.getImg(id)
    }
    //this.handleSearch();
    //console.log(this.data.pageIndex)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.loadMore()
    //console.log(this.data.pageIndex)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})